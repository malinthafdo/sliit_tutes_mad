package com.example.student.tute4_it18093292.DataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.List;

public final class DBHelper extends SQLiteOpenHelper
{
    public static final String DATABASE_NAME ="UserInfo.db";

    public DBHelper (Context context)
    {
        super(context,DATABASE_NAME, null ,1);
    }


    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + UserMaster.Users.TABLE_NAME + "("+
                                  UserMaster.Users._ID + "INTEGER PRIMARY KEY," +
                                  UserMaster.Users.COLUMN_NAME_password +"TEXT,"+
                                  UserMaster.Users.COLUMN_NAME_username+" TEXT)";

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addInfo(String username, String password)
    {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserMaster.Users.COLUMN_NAME_username,username);
        values.put(UserMaster.Users.COLUMN_NAME_password,password);


        long newRowId = db.insert(UserMaster.Users.TABLE_NAME,null ,values);
        if (newRowId >= 1)
            return true;
        else
            return false;

    }

    public List readAllInfo()
    {
        String [] projection = {
                UserMaster.Users._ID,
                UserMaster.Users.COLUMN_NAME_username,
                UserMaster.Users.COLUMN_NAME_password
        };


    }


}
