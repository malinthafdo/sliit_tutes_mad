package com.example.student.tute4_it18093292;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.student.tute4_it18093292.DataBase.DBHelper;

public class MainActivity extends  AppCompatActivity implements View.OnClickListener
{

    Button login,add,select_all,update,delete;
    TextView username,password;
    DBHelper dbHelper;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbHelper = new DBHelper(this);
        login = (Button)findViewById(R.id.login);
        add = (Button)findViewById(R.id.add);
        delete =(Button)findViewById(R.id.delete);
        update =(Button)findViewById(R.id.update);
        select_all=(Button)findViewById(R.id.selcet_all);

        username = (TextView)findViewById(R.id.username_text);
        password =(TextView)findViewById(R.id.password_text);

        login.setOnClickListener(this);
        add.setOnClickListener(this);
        delete.setOnClickListener(this);
        update.setOnClickListener(this);
        select_all.setOnClickListener(this);




    }

    @Override
    public void onClick(View v) {

    }
}
