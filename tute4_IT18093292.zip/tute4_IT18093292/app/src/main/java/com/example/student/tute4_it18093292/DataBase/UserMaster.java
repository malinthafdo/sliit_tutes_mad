package com.example.student.tute4_it18093292.DataBase;

import android.provider.BaseColumns;

public final class UserMaster
{

    private UserMaster(){}

    public static class Users implements BaseColumns
    {
        public static final String TABLE_NAME ="user";
        public static final String COLUMN_NAME_username="username";
        public static final String COLUMN_NAME_password="password";



    }

}
