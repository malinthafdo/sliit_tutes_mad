package tute.malintha.com.tute10_it18093292;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

import static tute.malintha.com.tute10_it18093292.DBhelper.DBC.DATABASE_NAME;


public class DBhelper extends SQLiteOpenHelper
{


    public DBhelper(Context context ) {
        super(context, DATABASE_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES_M);
        db.execSQL(SQL_CREATE_ENTRIES_U);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);

    }

    public static class DBC implements BaseColumns {

        public static final String DATABASE_NAME = "User";

        public static final String TABLE_NAME_U = "UserTable";
        public static final String COLUMN_U1 = "Name";
        public static final String COLUMN_U2 = "Password";
        public static final String COLUMN_U3 = "Type";

        public static final String TABLE_NAME_M = "MessageTable";
        public static final String COLUMN_M1 = "User";
        public static final String COLUMN_M2 = "Subject";
        public static final String COLUMN_M3 = "Message";

    }

    public static final String  SQL_CREATE_ENTRIES_U = "CREATE TABLE  " + DBC.TABLE_NAME_U + " (" +
    DBC._ID + " INTEGER PRIMARY KEY," +
    DBC.COLUMN_U1 + "TEXT," +
    DBC.COLUMN_U2  + " TEXT," +
            DBC.COLUMN_U3 + " TEXT)";

    public static final String  SQL_CREATE_ENTRIES_M = " CREATE TABLE " + DBC.TABLE_NAME_M + " (" +
            DBC._ID + " INTEGER PRIMARY KEY," +
            DBC.COLUMN_M1 + " TEXT," +
            DBC.COLUMN_M2  + " TEXT," +
            DBC.COLUMN_M3 + " TEXT)";




}
